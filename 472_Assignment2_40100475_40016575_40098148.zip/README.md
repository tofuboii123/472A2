Github URL: https://github.com/tofuboii123/472A2 
Assignment 2

Team AyeAyeAI:
* Members:
  * Kevin Jiang (40098148)
  * Tan-Phat Pham (40016575)
  * Weiliang Xie (40100475)

* Contribution: 
  * Keving Jiang: GBFS, Timer, Debugging 
  * Tan-Phat Pham: A*, Heuristic, Debugging
  * Weiliang Xie: UCS, Puzzle Generation, Scaling, Heuristic, Debugging  

* Instruction: 
  * Any IDE that supports Python can run the program.
  * Run `main.py` to run 50 randomly generated puzzles.
  * Search files are generated in	the "search" directory
  * Solution files are generated in the "solution" directory
  * Statistics on the results are generated in the "stats" directory.
